### 1 - Here we create the dataset we use for our research ###

###Data about deaths from pneumonia - open pneumonia-mortality-by-age.csv
death <- read.csv(file.choose(), header=T)
attach(death)

death1 <- death[!(death$Year != 2019),]

death_all_yers <- c()
for (i in 1:228){
  death_all_yers <- append(death_all_yers, sum(death1[i, 4:8]))
}

Countries <- death$Entity
Countries <-  unique(Countries)

Death_all_ages <- data.frame(Countries, death_all_yers)

###Data on GDP - open GDP_mod.csv
GDP0 <- read.csv(file.choose(), header=T, sep = ";")
attach(GDP0)

###Cross checking countries (to take only countries with all the data we need)
for (i in Death_all_ages$Countries){
  c = 0
  for (j in GDP0$Country.Name){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}

for (i in GDP0$Country.Name){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    GDP0 <- GDP0[!(GDP0$Country.Name == i),]
  }
}

###Outdoor air pollution - open air_pollution.csv
air0 <- read.csv(file.choose(), header=T, sep = ";")
attach(air0)
air1 <- air0[!(air0$Dim1 != "Total"),]
air <- air1[!(air1$Period != 2019),]

###Cross checking countries
for (i in Death_all_ages$Countries){
  c = 0
  for (j in air$Location){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}
for (i in air$Location){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    air <- air[!(air$Location == i),]
  }
}

for (i in GDP0$Country.Name){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    GDP0 <- GDP0[!(GDP0$Country.Name == i),]
  }
}

###Data on smoking - open share-of-adults-who-smoke.csv
data_sm <- read.csv(file.choose(), header = T)
attach(data_sm)

data_sm1 <- data_sm[!(data_sm$Year != 2019),]

###Cross checking countries
for (i in Death_all_ages$Countries){
  c = 0
  for (j in data_sm1$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}

for (i in data_sm1$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    data_sm1 <- data_sm1[!(data_sm1$Entity == i),]
  }
}

for (i in air$Location){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    air <- air[!(air$Location == i),]
  }
}

for (i in GDP0$Country.Name){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    GDP0 <- GDP0[!(GDP0$Country.Name == i),]
  }
}


###Data on age - open age-dependency-ratio-old.csv
age0 <- read.csv(file.choose(), header=T, sep = ",")
attach(age0)
age <- age0[!(age0$Year != 2019),]

###Cross checking countries
for (i in Death_all_ages$Countries){
  c = 0
  for (j in age$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}

for (i in age$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    age <- age[!(age$Entity == i),]
  }
}


###death rate no_handwashing data - open death-rates-no-handwashing.csv
no_han <- read.csv(file.choose(), header = T)
attach(no_han)

no_han <- no_han[!(no_han$Year != 2019),]

###Cross checking countries 
for (i in Death_all_ages$Countries){
  c = 0
  for (j in no_han$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}
for (i in no_han$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    no_han <- no_han[!(no_han$Entity == i),]
  }
}

###Data on passive smoke deaths - open deaths-from-secondhand-smoke.csv
sec_smoke <- read.csv(file.choose(), header = T)
attach(sec_smoke)

sec_smoke <- sec_smoke[!(sec_smoke$Year != 2019),]

###Cross checking countries
for (i in Death_all_ages$Countries){
  c = 0
  for (j in sec_smoke$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}
for (i in sec_smoke$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    sec_smoke <- sec_smoke[!(sec_smoke$Entity == i),]
  }
}

###Malnutrition_death_rate - open malnutrition-death-rates.csv
maln <- read.csv(file.choose(), header = T)
attach(maln)

maln <- maln[!(maln$Year != 2019),]

###Cross checking countries
for (i in Death_all_ages$Countries){
  c = 0
  for (j in maln$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}
for (i in maln$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    maln <- maln[!(maln$Entity == i),]
  }
}

###Indoor air pollution - open number-of-deaths-by-risk-factor.csv
in_air <- read.csv(file.choose(), header = T, sep = ";")
attach(in_air)

in_air <- in_air[!(in_air$Year != 2019),]

for (i in Death_all_ages$Countries){
  c = 0
  for (j in in_air$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}
for (i in in_air$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    in_air <- in_air[!(in_air$Entity == i),]
  }
}

###Adding geographic areas (for a nicer representation) - open countries_continent.csv
cont <- read.csv(file.choose(), header = T, sep = ";")
attach(cont)
cont <- unique(cont)

for (i in cont$Location){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    cont <- cont[!(cont$Location == i),]
  }
}

###Unsafe water sources - open share-deaths-unsafe-water.csv
wat0 <- read.csv(file.choose(), header = T)
attach(wat0)

wat <- wat0[!(wat0$Year != 2019),]

for (i in Death_all_ages$Countries){
  c = 0
  for (j in wat$Entity){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    Death_all_ages <- Death_all_ages[!(Death_all_ages$Countries == i),]
  }
}

for (i in wat$Entity){
  c = 0
  for (j in Death_all_ages$Countries){
    if(i == j){
      c <- c+1
    }
  }
  if (c == 0){
    wat <- wat[!(wat$Entity == i),]
  }
}


###Creating the data set

gea <- cont$ParentLocation
coun <- Death_all_ages$Countries
dep <- Death_all_ages$death_all_yers

gdp <- GDP0$X2019
old <- age$Old.age.dependency.ratio...Sex..all...Age..none...Variant..estimates
deh <- no_han$Deaths...Cause..All.causes...Risk..No.access.to.handwashing.facility...Sex..Both...Age..All.Ages..Rate.
dem <- maln$Deaths...Protein.energy.malnutrition...Sex..Both...Age..Age.standardized..Rate.
dew <-  wat$Deaths...Cause..All.causes...Risk..Unsafe.water.source...Sex..Both...Age..Age.standardized..Percent.

smo <- data_sm1$Prevalence.of.current.tobacco.use....of.adults.
psmo <- sec_smoke$Deaths...Cause..All.causes...Risk..Secondhand.smoke...Sex..Both...Age..All.Ages..Number.

air <- air$Take.me
inair <- in_air$Deaths...Cause..All.causes...Risk..Household.air.pollution.from.solid.fuels...Sex..Both...Age..All.Ages..Number.

Pneumonia <- data.frame(gea, coun, dep, gdp, old, deh, dem, dew, smo, psmo, air, inair)

### 2 - Here we perform all possible simple regressions, using dep as response. ###
###     Then we make the plots for dep vs each covariate ###

###First we perform a simple linear regression with dep  ~ each explanatory variable taken alone

###Linear reg. dep ~ smo
regression1 <- lm(dep ~ smo, data = Pneumonia)
summary(regression1)
plot(smo, dep, ylab = "Death from pneumonia", xlab = "Share of smokers")
abline(regression1)

res1 <- residuals(regression1)
plot(res1)
abline(h = 0)

###Linear reg. Death ~ GDP
regression2 <- lm(dep ~ gdp)
summary(regression2)
plot(gdp, dep, ylab = "Death from pneumonia", xlab = "GDP")
abline(regression2)

res2 <- residuals(regression2)
plot(res2)
abline(h = (max(res2)+min(res2))/2)

###Linear reg. Death ~ Old_depency_age
regression3 <- lm(dep ~ old)
summary(regression3)
plot(old, dep, ylab = "Death from pneumonia", xlab = "Old dependency")
abline(regression3)

res3 <- residuals(regression3)
plot(res3)
abline(h = (max(res3)+min(res3))/2)

###Linear reg. Death ~ Air_pollution
regression4 <- lm(dep ~ air)
summary(regression4)
plot(air, dep, ylab = "Death from pneumonia", xlab = "Air pollution")
abline(regression4)

res4 <- residuals(regression4)
plot(res4)
abline(h = (max(res4)+min(res4))/2)

###Linear reg. Death ~ No_handwashing_death_rate
regression5 <- lm(dep ~ deh)
summary(regression5)
plot(deh, dep, ylab = "Death from pneumonia", xlab = "No handwashing death rate")
abline(regression5)

res5 <- residuals(regression5)
plot(res5)
abline(h = (max(res5)+min(res5))/2)

###Linear reg. Death ~ Second_hand_smoking_death
regression6 <- lm(dep ~ psmo)
summary(regression6)
plot(psmo, dep, ylab = "Death from pneumonia", xlab = "Second hand smoking deaths")
abline(regression6)

res6 <- residuals(regression6)
plot(res6)
abline(h = (max(res6)+min(res6))/2)

###Linear reg. Death ~ Malnutrition_death_rate
regression7 <- lm(dep ~ dem)
summary(regression7)
plot(dem, dep , ylab = "Death from pneumonia", xlab = "Malnutrion death rate")
abline(regression7)

res7 <- residuals(regression7)
plot(res7)
abline(h = (250))

###Linear reg. Death ~ Indoor_air_pollution_death
regression8 <- lm(dep ~ inair)
summary(regression8)
plot(inair, dep, ylab = "Death from pneumonia", xlab = "Indoor air pollution deaths")
abline(regression8)

res8 <- residuals(regression8)
plot(res8)
abline(h = (max(res8)+min(res8))/2)

###Linear reg. Death ~ Unsafe_water_death_rate
regression9 <- lm(dep ~ dew)
summary(regression9)
plot(dew, dep, ylab = "Death from pneumonia", xlab = "Unsafe water death rate")
abline(regression9)

res9 <- residuals(regression9)
plot(res9)
abline(h = (max(res9)+min(res9))/2)


###Nicer graphic representation, using different colors for different geographic areas
library(ggplot2)
theme_set(theme_bw())

###Death vs share_smokers
ggplot(Pneumonia, aes(y = dep, x = smo, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Share of smokers") +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "black", size = 12, face = 2), panel.grid = element_blank())   

###Death vs deaths_second_hand_smoke
ggplot(Pneumonia, aes(y = dep, x = psmo, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Second hand smoking death") +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "black", size = 12, face = 2), panel.grid = element_blank()) +
  xlim(c(0,40000))

###Death vs GDP
ggplot(Pneumonia, aes(y = dep, x = gdp, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "GDP per capita" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank())  

###Death vs Old age dependence
ggplot(Pneumonia, aes(y = dep, x = old, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Old age dependence" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank()) 

###Death vs Air_pollution
ggplot(Pneumonia, aes(y = dep, x = air, color = gea)) +
  geom_point(shape = "O", size = 3)+
  labs(y = "Deaths from pneumonia", x = "Air pollution" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank())  

###Death vs No_handwashing_death_rate
ggplot(Pneumonia, aes(y = dep, x = deh, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "No handwashing death rate" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank())  

###Death vs Malnutrition_death_rate
ggplot(Pneumonia, aes(y = dep, x = dem, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Malnutrition death rate" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank())  

###Death vs Indoor_air_pollution_death
ggplot(Pneumonia, aes(y = dep, x = inair, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Indoor air pollution deaths" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank()) +
  xlim(c(0,50000))

###Death vs Unsafe_water_death_rate
ggplot(Pneumonia, aes(y = dep, x = dew, color = gea)) +
  geom_point(shape = "O", size = 3) +
  labs(y = "Deaths from pneumonia", x = "Unsafe water death rate" ) +
  theme(axis.title = element_text(vjust = 0, size = 10, color = "black", face = "bold")) +
  scale_color_brewer(
    name = "Geographic area:",
    labels = c("Africa", "Americas", "EastMedit.", "Europe", "SouthEast Asia", "WestPacific"),
    palette = "Set2") +
  theme(legend.title = element_text(
    color = "Black", size = 12, face = 2), panel.grid = element_blank())  


### 3 - Here we perform the multiple regressions with the first two model we selected, ###
###     that contain all the covariates ###

###Multiple linear regression - dep###
mul_regression <- lm(dep ~ gdp + old + deh + dew + dem + smo + psmo + air + inair)
summary(mul_regression)

ress <- residuals(mul_regression)
plot(ress, ylab="Residuals",)

###Checking homoscedasticity
#Fitted vs residuals
plot(fitted(mul_regression), ress, xlab = "Fitted", ylab = "Residuals")
abline(h= 0)

###Checking normality
hist(ress, xlab="Residuals", breaks=10)
qqnorm(ress,ylab="Residuals",xlab="Normal Scores") 
qqline(ress, col="red")
shapiro.test(residuals(mul_regression))


###Multiple linear regression - log(dep)###
mul_regression2 <- lm(log(dep) ~ gdp + old + deh + dew + dem + smo + psmo + air + inair)
summary(mul_regression2)

ress2 <- residuals(mul_regression2)
plot(ress2, ylab="Residuals",)

###Checking homoscedasticity
#Fitted vs residuals
plot(fitted(mul_regression2), ress2, xlab = "Fitted", ylab = "Residuals")
abline(h= 0)

###Checking normality
hist(ress2, xlab="Residuals", breaks=10)
qqnorm(ress2,ylab="Residuals",xlab="Normal Scores") 
qqline(ress2, col="red")
shapiro.test(residuals(mul_regression2))


### 4 - Here we perform model selection by step AIC and then BIC. ###
###     Then we perform a multiple linear regression with the best model we find ###

library(MASS)

###Multiple linear regression - dep###
mul_regression <- lm(dep ~ gdp + old + deh + dew + dem + smo + psmo + air + inair)
summary(mul_regression)


###Multiple linear regression - log(dep)###
mul_regression2 <- lm(log(dep) ~ gdp + old + deh + dew + dem + smo + psmo + air + inair)
summary(mul_regression2)


#selecting the best model by AIC (from mul_regression) using both step-down and step-up
step.model <- stepAIC(mul_regression, direction = "both", 
                      trace = FALSE)
summary(step.model)


#selecting the best model by AIC (from mul_regression2) using both step-down and step-up
step.model2 <- stepAIC(mul_regression2, direction = "both", 
                       trace = FALSE)
summary(step.model2)



###BIC to understand whether to include smo or not
#Model 1: model (dep) without dew, dem, gdp, inair, psmo and smo
model1 <- lm(dep ~ old + air + deh)
summary(model1)


#Model 2: model (log(dep)) without dew, dem, gdp, inair, psmo
model2 <- lm(log(dep) ~ smo + old + air + deh)
summary(model2)


BIC(model1, model2)
#result: model2 is much better


###Checking homoscedasticity
#Fitted vs residuals
ress_model2 <- residuals(model2)
plot(fitted(model2), ress_model2, xlab = "Fitted", ylab = "Residuals")
abline(h= 0)

###Checking normality
hist(ress_model2, xlab="Residuals", breaks=10)
qqnorm(ress_model2,ylab="Residuals",xlab="Normal Scores") 
qqline(ress_model2, col="red")
shapiro.test(ress_model2)
